import java.util.LinkedList;

public class FabricaBaterias{
    public static void main(String[] args) {
        Almacen deposito = new Almacen();

        Fabrica pro = new Fabrica(deposito);
        Thread[] operario = new Thread[2];

        for (int i = 0; i < operario.length; i++) {
            operario[i] = new Operario(deposito, i + 1);
        }

        pro.start();
        for (Thread c : operario) {
            c.start();
        }

        try {
            pro.join();
            for (Thread c : operario) {
                c.join();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(" FIN DE LA SIMULACION");
    }
}

class Fabrica extends Thread {
    Almacen deposito;

    public Fabrica(Almacen deposito) {
        this.deposito = deposito;
    }

    @Override
    public void run() {
        for (int i = 0; i < 12; i++) {
            deposito.fabricar();;            
            try { Thread.sleep(400); } catch (InterruptedException e) {} 
        }
    }
}

class Operario extends Thread {
    Almacen deposito;
    int id;

    public Operario(Almacen deposito, int id) {
        this.deposito = deposito;
        this.id = id;
    }

    @Override
    public void run() {
        while (deposito.getContador() < 12) {
            deposito.recoger(id);
            try { Thread.sleep(1800); } catch (InterruptedException e) {}
        }
        System.out.println("Operario-"+id+" ha terminado de montar baterias");
    }
}


class Almacen {
    private LinkedList<Integer> cola;
    private final int CAPACIDAD_MAXIMA = 3;
    private int contador=0;


    public Almacen() {
        this.cola = new LinkedList<>();
    }

    public int getContador(){
        return contador;
    }

    public synchronized void fabricar() {

        while (cola.size() == CAPACIDAD_MAXIMA) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        contador++;
        cola.add(contador);
        
        System.out.println("Fabricante produce bateria "+contador+" | Baterias en Almacen = "+cola.size());
        notifyAll();
    }

    public synchronized boolean recoger(int idOperario) {
        while (cola.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }


        int bateria = cola.removeFirst(); 
        System.out.println("Operario-"+idOperario+" recoge bateria "+bateria+" | Baterias en Almacen = "+cola.size());

        notifyAll();
        return true;
    }
}